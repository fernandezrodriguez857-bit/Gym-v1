import { motion, AnimatePresence } from 'framer-motion';
import { User, Shield } from 'lucide-react';

type Role = 'client' | 'admin';

type RoleSwitcherProps = {
  role: Role;
  onChange: (role: Role) => void;
};

export function RoleSwitcher({ role, onChange }: RoleSwitcherProps) {
  return (
    <div className="fixed right-4 top-4 z-40 sm:right-6 sm:top-6">
      <div className="glass flex items-center gap-1 rounded-full p-1">
        {(['client', 'admin'] as const).map((r) => (
          <button
            key={r}
            onClick={() => onChange(r)}
            className="relative flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition-colors sm:px-4"
          >
            {role === r && (
              <motion.div
                layoutId="role-pill"
                className="absolute inset-0 rounded-full"
                style={{
                  backgroundColor: r === 'admin' ? 'rgba(204,255,0,0.12)' : 'rgba(63,63,70,0.5)',
                  border: r === 'admin' ? '1px solid rgba(204,255,0,0.3)' : '1px solid rgba(63,63,70,0.4)',
                }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              />
            )}
            <span className={`relative z-10 flex items-center gap-1.5 ${role === r ? (r === 'admin' ? 'text-accent' : 'text-zinc-100') : 'text-zinc-500'}`}>
              {r === 'client' ? <User className="h-3 w-3" /> : <Shield className="h-3 w-3" />}
              <span className="hidden sm:inline">{r === 'client' ? 'Cliente' : 'Dueño'}</span>
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

export type { Role };

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search, AlertTriangle, Clock, Dumbbell, Flame, Award, Pencil, Check, X,
} from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { Button } from '@/components/ui/Button';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { CountdownTimer } from '@/components/ui/CountdownTimer';
import { supabase, type Member } from '@/lib/supabase';
import { getDaysRemaining, getMemberStatus, formatDate } from '@/lib/utils';

function getLoyaltyInfo(loyaltyStart: string): { text: string; months: number; years: number; label: string; percent: number } {
  const start = new Date(loyaltyStart).getTime();
  const now = Date.now();
  const diffMs = now - start;
  const days = Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
  const months = Math.floor(days / 30);
  const years = Math.floor(months / 12);
  const remainingMonths = months % 12;

  let text: string;
  let label: string;

  if (years >= 1) {
    text = `${years}a${remainingMonths > 0 ? ` ${remainingMonths}m` : ''}`;
    label = years >= 2 ? 'Veterano' : 'Fiel';
  } else if (months >= 1) {
    text = `${months}m`;
    label = months >= 6 ? 'Fiel' : 'Constante';
  } else {
    text = `${days}d`;
    label = 'Nuevo';
  }

  const percent = Math.min(100, Math.max(3, months * 5));

  return { text, months, years, label, percent };
}

function ProgressCard({ member }: { member: Member }) {
  const isDaily = member.plan_type === 'daily';
  const start = new Date(member.start_date).getTime();
  const end = new Date(member.end_date).getTime();
  const now = Date.now();
  const total = end - start;
  const elapsed = Math.max(0, now - start);
  const percent = Math.min(100, Math.max(0, (elapsed / total) * 100));

  const remainingDays = Math.max(0, getDaysRemaining(member.end_date));
  const remainingMs = Math.max(0, end - now);
  const remainingHours = Math.floor(remainingMs / (1000 * 60 * 60));
  const remainingMins = Math.floor((remainingMs % (1000 * 60 * 60)) / (1000 * 60));

  return (
    <GlassCard className="overflow-hidden p-6">
      <div className="mb-5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent/10">
            {isDaily ? <Clock className="h-4 w-4 text-accent" /> : <Dumbbell className="h-4 w-4 text-accent" />}
          </div>
          <span className="text-sm font-medium text-zinc-300">
            {isDaily ? 'Tiempo de tu pase' : 'Progreso del mes'}
          </span>
        </div>
        <span className="text-xs text-zinc-500">
          {isDaily ? 'Pase Diario' : 'Mensualidad'}
        </span>
      </div>

      {/* Big remaining number */}
      <div className="mb-6 text-center">
        <motion.p
          key={isDaily ? 'daily' : 'monthly'}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="text-5xl font-bold tracking-tight text-white"
        >
          {isDaily ? (
            <span className="tabular-nums text-accent">
              {String(remainingHours).padStart(2, '0')}
              <span className="text-zinc-700">:</span>
              {String(remainingMins).padStart(2, '0')}
            </span>
          ) : (
            <span className="text-accent">{remainingDays}</span>
          )}
        </motion.p>
        <p className="mt-1 text-xs text-zinc-500">
          {isDaily ? 'horas : minutos restantes' : 'días restantes'}
        </p>
      </div>

      {/* Progress bar */}
      <div className="relative mb-2 h-3 overflow-hidden rounded-full bg-zinc-800/80">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${percent}%` }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
          className={`h-full rounded-full ${
            percent > 80
              ? 'bg-gradient-to-r from-red-500/70 to-red-400'
              : percent > 60
              ? 'bg-gradient-to-r from-yellow-500/70 to-yellow-400'
              : 'bg-gradient-to-r from-accent/60 to-accent'
          }`}
        />
      </div>

      <div className="flex items-center justify-between text-[10px] text-zinc-600">
        <span>{formatDate(member.start_date)}</span>
        <span>{Math.round(percent)}% usado</span>
        <span>{formatDate(member.end_date)}</span>
      </div>
    </GlassCard>
  );
}

function LoyaltyWidget({ member, onUpdate }: { member: Member; onUpdate: () => void }) {
  const [editing, setEditing] = useState(false);
  const [year, setYear] = useState('');
  const [month, setMonth] = useState('');
  const [saving, setSaving] = useState(false);

  const loyaltyStart = member.loyalty_start_date || member.created_at;
  const loyalty = getLoyaltyInfo(loyaltyStart);

  function startEdit() {
    const d = new Date(loyaltyStart);
    setYear(String(d.getFullYear()));
    setMonth(String(d.getMonth() + 1).padStart(2, '0'));
    setEditing(true);
  }

  async function saveLoyalty() {
    const y = parseInt(year);
    const m = parseInt(month);
    if (isNaN(y) || isNaN(m) || m < 1 || m > 12 || y < 2000 || y > new Date().getFullYear()) return;

    const dateStr = new Date(y, m - 1, 1).toISOString();
    setSaving(true);
    try {
      const { error } = await supabase
        .from('members')
        .update({ loyalty_start_date: dateStr })
        .eq('id', member.id);

      if (error) throw error;
      setEditing(false);
      onUpdate();
    } catch (err) {
      console.error('Loyalty update error:', err);
      alert('No se pudo guardar. Intenta nuevamente.');
    } finally {
      setSaving(false);
    }
  }

  const months = Array.from({ length: 12 }, (_, i) => i + 1);
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: currentYear - 1999 }, (_, i) => currentYear - i);

  return (
    <GlassCard className="overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-zinc-800/60 p-5">
        <div className="flex items-center gap-2">
          <Flame className="h-4 w-4 text-accent" />
          <span className="text-sm font-medium text-zinc-300">Antigüedad / Racha</span>
        </div>
        {!editing && (
          <button
            onClick={startEdit}
            className="flex items-center gap-1.5 rounded-lg px-2 py-1 text-xs text-zinc-500 transition-colors hover:bg-zinc-800/40 hover:text-zinc-300"
          >
            <Pencil className="h-3 w-3" />
            Editar
          </button>
        )}
      </div>

      <div className="p-6">
        <AnimatePresence mode="wait">
          {!editing ? (
            <motion.div
              key="display"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              {/* Big number + label — iPhone widget style */}
              <div className="mb-6 flex items-end justify-between">
                <div>
                  <motion.p
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="text-4xl font-bold tracking-tight text-white"
                  >
                    {loyalty.text}
                  </motion.p>
                  <p className="mt-1 text-xs text-zinc-500">Tiempo en Gym Local</p>
                </div>
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ type: 'spring', stiffness: 200, damping: 15, delay: 0.1 }}
                  className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold ${
                    loyalty.label === 'Veterano'
                      ? 'bg-accent/10 text-accent border border-accent/20'
                      : loyalty.label === 'Fiel'
                      ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20'
                      : loyalty.label === 'Constante'
                      ? 'bg-green-500/10 text-green-400 border border-green-500/20'
                      : 'bg-zinc-800/50 text-zinc-400 border border-zinc-700/50'
                  }`}
                >
                  <Award className="h-3 w-3" />
                  {loyalty.label}
                </motion.div>
              </div>

              {/* Ring progress — Apple activity ring style */}
              <div className="mb-6 flex items-center gap-5">
                <div className="relative h-24 w-24 shrink-0">
                  <svg className="h-full w-full -rotate-90" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(63,63,70,0.5)" strokeWidth="8" />
                    <motion.circle
                      cx="50"
                      cy="50"
                      r="42"
                      fill="none"
                      stroke="#ccff00"
                      strokeWidth="8"
                      strokeLinecap="round"
                      strokeDasharray={2 * Math.PI * 42}
                      initial={{ strokeDashoffset: 2 * Math.PI * 42 }}
                      animate={{ strokeDashoffset: 2 * Math.PI * 42 * (1 - loyalty.percent / 100) }}
                      transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-lg font-bold text-white">{loyalty.months}</span>
                    <span className="text-[9px] text-zinc-500">meses</span>
                  </div>
                </div>

                <div className="flex-1 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-zinc-500">Fidelidad</span>
                    <span className="font-semibold text-accent">{loyalty.percent}%</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-zinc-500">Desde</span>
                    <span className="text-zinc-300">
                      {new Date(loyaltyStart).toLocaleDateString('es-PE', { month: 'short', year: 'numeric' })}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-zinc-500">Estado</span>
                    <span className="flex items-center gap-1 text-green-400">
                      <motion.span
                        animate={{ opacity: [1, 0.4, 1] }}
                        transition={{ duration: 2, repeat: Infinity }}
                        className="h-1.5 w-1.5 rounded-full bg-green-400"
                      />
                      Activo
                    </span>
                  </div>
                </div>
              </div>

              {/* Milestone chips */}
              <div className="flex flex-wrap gap-2">
                {[
                  { label: '1 semana', reached: loyalty.months >= 0 },
                  { label: '1 mes', reached: loyalty.months >= 1 },
                  { label: '3 meses', reached: loyalty.months >= 3 },
                  { label: '6 meses', reached: loyalty.months >= 6 },
                  { label: '1 año', reached: loyalty.months >= 12 },
                  { label: '2 años', reached: loyalty.months >= 24 },
                ].map((m) => (
                  <span
                    key={m.label}
                    className={`flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-medium ${
                      m.reached
                        ? 'bg-accent/10 text-accent border border-accent/20'
                        : 'bg-zinc-800/40 text-zinc-600 border border-zinc-700/40'
                    }`}
                  >
                    {m.reached && <Check className="h-2.5 w-2.5" />}
                    {m.label}
                  </span>
                ))}
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="edit"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <p className="mb-1 text-sm font-medium text-white">¿Cuándo empezaste a entrenar aquí?</p>
              <p className="mb-5 text-xs text-zinc-500">
                Configura tu fecha de inicio para mostrar tu fidelidad real con Gym Local.
              </p>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1.5 block text-[10px] font-medium tracking-wide text-zinc-500">MES</label>
                  <select
                    value={month}
                    onChange={(e) => setMonth(e.target.value)}
                    className="w-full rounded-xl border border-zinc-800 bg-zinc-900/60 px-3 py-2.5 text-sm text-white outline-none transition-colors focus:border-accent/50"
                  >
                    {months.map((m) => (
                      <option key={m} value={String(m).padStart(2, '0')}>
                        {new Date(2000, m - 1, 1).toLocaleDateString('es-PE', { month: 'long' })}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="mb-1.5 block text-[10px] font-medium tracking-wide text-zinc-500">AÑO</label>
                  <select
                    value={year}
                    onChange={(e) => setYear(e.target.value)}
                    className="w-full rounded-xl border border-zinc-800 bg-zinc-900/60 px-3 py-2.5 text-sm text-white outline-none transition-colors focus:border-accent/50"
                  >
                    {years.map((y) => (
                      <option key={y} value={String(y)}>{y}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="mt-5 flex gap-3">
                <Button variant="secondary" fullWidth onClick={() => setEditing(false)}>
                  <span className="flex items-center justify-center gap-2">
                    <X className="h-4 w-4" />
                    Cancelar
                  </span>
                </Button>
                <Button fullWidth onClick={saveLoyalty} disabled={saving}>
                  <span className="flex items-center justify-center gap-2">
                    <Check className="h-4 w-4" />
                    {saving ? 'Guardando...' : 'Guardar'}
                  </span>
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </GlassCard>
  );
}

export function ProfileCheck() {
  const [dni, setDni] = useState('');
  const [member, setMember] = useState<Member | null>(null);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  async function handleSearch() {
    if (!dni.trim()) return;
    setLoading(true);
    setSearched(true);
    try {
      const { data, error } = await supabase
        .from('members')
        .select('*')
        .eq('dni', dni.trim())
        .order('created_at', { ascending: false })
        .maybeSingle();

      if (error) throw error;
      setMember(data as Member | null);
    } catch (err) {
      console.error('Search error:', err);
      setMember(null);
    } finally {
      setLoading(false);
    }
  }

  async function refreshMember() {
    if (!member) return;
    const { data } = await supabase
      .from('members')
      .select('*')
      .eq('id', member.id)
      .maybeSingle();
    if (data) setMember(data as Member);
  }

  const status = member ? getMemberStatus(member) : null;
  const daysLeft = member ? getDaysRemaining(member.end_date) : 0;
  const showAlert = status === 'proximo' || status === 'vencido';
  const isDailyActive = member?.plan_type === 'daily' && status === 'vigente';

  return (
    <section id="estado" className="mx-auto max-w-lg px-6 py-24">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        <motion.h2
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-2 text-center text-3xl font-bold tracking-tight text-white"
        >
          Consulta tu estado
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="mb-8 text-center text-sm text-zinc-400"
        >
          Ingresa tu DNI para ver tu membresía
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.15 }}
          className="flex gap-2"
        >
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-600" />
            <input
              type="text"
              value={dni}
              onChange={(e) => setDni(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="12345678"
              maxLength={8}
              className="w-full rounded-xl border border-zinc-800 bg-zinc-900/50 py-3 pl-10 pr-4 text-sm text-white placeholder-zinc-600 outline-none transition-colors focus:border-accent/50"
            />
          </div>
          <Button onClick={handleSearch} disabled={loading || !dni.trim()}>
            {loading ? '...' : 'Consultar'}
          </Button>
        </motion.div>

        <AnimatePresence mode="wait">
          {searched && !loading && (
            <motion.div
              key={member ? 'found' : 'not-found'}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className="mt-6 space-y-4"
            >
              {member ? (
                <>
                  {/* Alert */}
                  {showAlert && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className={`flex items-center gap-3 rounded-xl border p-4 ${
                        status === 'vencido'
                          ? 'border-red-500/30 bg-red-500/10'
                          : 'border-yellow-500/30 bg-yellow-500/10'
                      }`}
                    >
                      <motion.div
                        animate={status === 'vencido' ? { rotate: [0, -10, 10, 0] } : {}}
                        transition={{ duration: 0.5, repeat: 3 }}
                      >
                        <AlertTriangle
                          className={`h-5 w-5 shrink-0 ${
                            status === 'vencido' ? 'text-red-400' : 'text-yellow-400'
                          }`}
                        />
                      </motion.div>
                      <div>
                        <p
                          className={`text-sm font-semibold ${
                            status === 'vencido' ? 'text-red-400' : 'text-yellow-400'
                          }`}
                        >
                          {status === 'vencido'
                            ? '¡Tu membresía ha vencido!'
                            : '¡Tu membresía está por vencer!'}
                        </p>
                        <p className="text-xs text-zinc-400">
                          {status === 'vencido'
                            ? `Venció hace ${Math.abs(daysLeft)} día${Math.abs(daysLeft) !== 1 ? 's' : ''}. Renueva para seguir entrenando.`
                            : `Te quedan solo ${daysLeft} día${daysLeft !== 1 ? 's' : ''}. ¡Renueva ya!`}
                        </p>
                      </div>
                    </motion.div>
                  )}

                  {/* Profile card */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.05 }}
                  >
                    <GlassCard className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-zinc-800/50">
                            <Dumbbell className="h-5 w-5 text-accent" />
                          </div>
                          <div>
                            <p className="font-semibold text-white">{member.name}</p>
                            <p className="text-xs text-zinc-500">DNI: {member.dni}</p>
                          </div>
                        </div>
                        <StatusBadge status={status!} />
                      </div>

                      <div className="mt-5 grid grid-cols-2 gap-3">
                        <div className="rounded-xl border border-zinc-800 bg-zinc-900/40 p-3.5">
                          <div className="flex items-center gap-1.5 text-zinc-500">
                            <Clock className="h-3 w-3" />
                            <span className="text-[10px] font-medium tracking-wide">INICIO</span>
                          </div>
                          <p className="mt-1.5 text-sm font-semibold text-white">
                            {formatDate(member.start_date)}
                          </p>
                        </div>
                        <div className="rounded-xl border border-zinc-800 bg-zinc-900/40 p-3.5">
                          <div className="flex items-center gap-1.5 text-zinc-500">
                            <Clock className="h-3 w-3" />
                            <span className="text-[10px] font-medium tracking-wide">VENCE</span>
                          </div>
                          <p className="mt-1.5 text-sm font-semibold text-white">
                            {formatDate(member.end_date)}
                          </p>
                        </div>
                      </div>
                    </GlassCard>
                  </motion.div>

                  {/* Live countdown for active daily pass */}
                  {isDailyActive && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: 0.1 }}
                    >
                      <GlassCard className="p-6">
                        <div className="mb-4 flex items-center gap-2">
                          <Clock className="h-4 w-4 text-accent" />
                          <span className="text-sm font-medium text-zinc-300">Tu pase diario está activo</span>
                        </div>
                        <CountdownTimer endDate={member.end_date} />
                      </GlassCard>
                    </motion.div>
                  )}

                  {/* Minimalist progress card (replaces old calendar) */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.15 }}
                  >
                    <ProgressCard member={member} />
                  </motion.div>

                  {/* Editable Loyalty widget */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.2 }}
                  >
                    <LoyaltyWidget member={member} onUpdate={refreshMember} />
                  </motion.div>
                </>
              ) : (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                >
                  <GlassCard className="p-8 text-center">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: 'spring', stiffness: 200, damping: 15 }}
                      className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-zinc-800/50"
                    >
                      <Search className="h-5 w-5 text-zinc-500" />
                    </motion.div>
                    <p className="text-sm text-zinc-400">
                      No encontramos una membresía con ese DNI.
                    </p>
                    <p className="mt-1 text-xs text-zinc-600">
                      Si ya pagaste, espera a que el dueño apruebe tu pago.
                    </p>
                  </GlassCard>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </section>
  );
}

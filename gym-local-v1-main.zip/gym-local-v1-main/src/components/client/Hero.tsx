import { motion } from 'framer-motion';
import { Dumbbell, ArrowDown } from 'lucide-react';
import { Placeholder } from '@/components/ui/Placeholder';
import { Button } from '@/components/ui/Button';

type HeroProps = {
  onCTA: () => void;
};

export function Hero({ onCTA }: HeroProps) {
  return (
    <section className="relative min-h-screen w-full overflow-hidden">
      {/* Background placeholder */}
      <div className="absolute inset-0 z-0">
        <Placeholder
          label="Espacio para Video / Foto del Gym"
          aspect="auto"
          className="h-full w-full rounded-none border-none"
          icon={<Dumbbell className="h-5 w-5" />}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-zinc-950/60 via-zinc-950/80 to-zinc-950" />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto flex min-h-screen max-w-4xl flex-col items-center justify-center px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="mb-6"
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-zinc-800 bg-zinc-900/50 px-4 py-1.5 text-xs font-medium tracking-wide text-zinc-400 backdrop-blur-xl">
            <Dumbbell className="h-3 w-3 text-accent" />
            GYM LOCAL
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
          className="text-5xl font-bold tracking-tight text-white sm:text-7xl"
        >
          Tu cuerpo,<br />
          <span className="text-accent">tu templo.</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          className="mt-6 max-w-xl text-lg font-light text-zinc-400"
        >
          Entrena en un espacio diseñado para superar tus límites. Pase diario o mensual, pago simple con Yape.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
          className="mt-10 flex flex-col items-center gap-4"
        >
          <Button size="lg" onClick={onCTA} className="accent-glow">
            Entrenar Hoy
          </Button>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="text-zinc-600"
          >
            <ArrowDown className="h-4 w-4" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}

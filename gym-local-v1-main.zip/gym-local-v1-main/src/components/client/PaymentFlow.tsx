import { useState, useRef, type ChangeEvent } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { QrCode, Upload, Check, ArrowLeft, Smartphone, Clock } from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { Button } from '@/components/ui/Button';
import { Placeholder } from '@/components/ui/Placeholder';
import { PLAN_PRICES, PLAN_DURATIONS, type PlanType } from '@/lib/supabase';
import { supabase } from '@/lib/supabase';

type PaymentFlowProps = {
  plan: PlanType;
  onBack: () => void;
  onComplete: () => void;
};

type Step = 'qr' | 'form' | 'pending';

const YAPE_PHONE = '999 888 777';

export function PaymentFlow({ plan, onBack, onComplete }: PaymentFlowProps) {
  const [step, setStep] = useState<Step>('qr');
  const [name, setName] = useState('');
  const [dni, setDni] = useState('');
  const [receiptFile, setReceiptFile] = useState<string | null>(null);
  const [receiptName, setReceiptName] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const price = PLAN_PRICES[plan];
  const duration = PLAN_DURATIONS[plan];

  async function handleSubmit() {
    if (!name.trim() || !dni.trim()) return;
    setSubmitting(true);
    try {
      const { error } = await supabase.from('payments').insert({
        name: name.trim(),
        dni: dni.trim(),
        plan_type: plan,
        amount: price,
        status: 'pendiente',
        receipt_data: receiptFile,
      });
      if (error) throw error;
      setStep('pending');
    } catch (err) {
      console.error('Payment submission error:', err);
      alert('Hubo un error al enviar tu comprobante. Intenta nuevamente.');
    } finally {
      setSubmitting(false);
    }
  }

  function handleFileChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setReceiptName(file.name);
    const reader = new FileReader();
    reader.onloadend = () => setReceiptFile(reader.result as string);
    reader.readAsDataURL(file);
  }

  return (
    <div className="mx-auto max-w-lg px-6 py-12">
      <button
        onClick={onBack}
        className="mb-6 flex items-center gap-2 text-sm text-zinc-500 transition-colors hover:text-zinc-300"
      >
        <ArrowLeft className="h-4 w-4" />
        Volver
      </button>

      <AnimatePresence mode="wait">
        {/* QR Step */}
        {step === 'qr' && (
          <motion.div
            key="qr"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <GlassCard className="p-8">
              <div className="mb-6 text-center">
                <div className="mx-auto mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-green-500/10">
                  <Smartphone className="h-5 w-5 text-green-400" />
                </div>
                <h2 className="text-xl font-semibold text-white">Pago con Yape</h2>
                <p className="mt-1 text-sm text-zinc-400">
                  {plan === 'daily' ? 'Pase Diario' : 'Mensualidad'} · S/ {price.toFixed(2)}
                </p>
              </div>

              <Placeholder
                label="Espacio para QR de Yape"
                aspect="square"
                className="mx-auto max-w-[280px]"
                icon={<QrCode className="h-6 w-6" />}
              />

              <div className="mt-6 rounded-xl border border-zinc-800 bg-zinc-900/50 p-4 text-center">
                <p className="text-xs text-zinc-500">Número Yape del dueño</p>
                <p className="mt-1 text-2xl font-bold tracking-wider text-white">{YAPE_PHONE}</p>
              </div>

              <div className="mt-4 flex items-center justify-center gap-2 text-xs text-zinc-500">
                <Clock className="h-3 w-3" />
                {duration}
              </div>

              <Button fullWidth className="mt-6" onClick={() => setStep('form')}>
                Ya pagué — Subir comprobante
              </Button>
            </GlassCard>
          </motion.div>
        )}

        {/* Form Step */}
        {step === 'form' && (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <GlassCard className="p-8">
              <h2 className="mb-6 text-xl font-semibold text-white">Completa tus datos</h2>

              <div className="space-y-4">
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-zinc-400">
                    Nombre completo
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Tu nombre"
                    className="w-full rounded-xl border border-zinc-800 bg-zinc-900/50 px-4 py-3 text-sm text-white placeholder-zinc-600 outline-none transition-colors focus:border-accent/50"
                  />
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-medium text-zinc-400">
                    DNI
                  </label>
                  <input
                    type="text"
                    value={dni}
                    onChange={(e) => setDni(e.target.value)}
                    placeholder="12345678"
                    maxLength={8}
                    className="w-full rounded-xl border border-zinc-800 bg-zinc-900/50 px-4 py-3 text-sm text-white placeholder-zinc-600 outline-none transition-colors focus:border-accent/50"
                  />
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-medium text-zinc-400">
                    Captura del comprobante Yape
                  </label>
                  <button
                    onClick={() => fileRef.current?.click()}
                    className="flex w-full items-center gap-3 rounded-xl border border-dashed border-zinc-700 bg-zinc-900/30 px-4 py-4 text-left transition-colors hover:border-accent/40"
                  >
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-zinc-800/50">
                      <Upload className="h-4 w-4 text-zinc-400" />
                    </div>
                    <div className="min-w-0">
                      {receiptName ? (
                        <>
                          <p className="truncate text-sm text-accent">{receiptName}</p>
                          <p className="text-xs text-zinc-500">Toca para cambiar</p>
                        </>
                      ) : (
                        <>
                          <p className="text-sm text-zinc-300">Subir captura</p>
                          <p className="text-xs text-zinc-500">JPG o PNG</p>
                        </>
                      )}
                    </div>
                  </button>
                  <input
                    ref={fileRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </div>
              </div>

              <Button
                fullWidth
                className="mt-6"
                onClick={handleSubmit}
                disabled={!name.trim() || !dni.trim() || submitting}
              >
                {submitting ? 'Enviando...' : 'Enviar comprobante'}
              </Button>
            </GlassCard>
          </motion.div>
        )}

        {/* Pending Step */}
        {step === 'pending' && (
          <motion.div
            key="pending"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
          >
            <GlassCard className="p-10 text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', stiffness: 200, damping: 15, delay: 0.1 }}
                className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-yellow-500/10"
              >
                <Clock className="h-8 w-8 text-yellow-400" />
              </motion.div>

              <h2 className="text-xl font-semibold text-white">Pendiente de Aprobación</h2>
              <p className="mx-auto mt-3 max-w-xs text-sm text-zinc-400">
                Tu comprobante fue enviado. El dueño del gym lo revisará y activará tu acceso lo antes posible.
              </p>

              <div className="mt-6 rounded-xl border border-yellow-500/20 bg-yellow-500/5 p-4">
                <p className="text-xs text-yellow-400/80">
                  Presenta tu DNI en recepción para confirmar tu ingreso una vez aprobado.
                </p>
              </div>

              <Button fullWidth variant="secondary" className="mt-6" onClick={onComplete}>
                Volver al inicio
              </Button>
            </GlassCard>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Dumbbell, User } from 'lucide-react';
import { Hero } from './Hero';
import { Plans } from './Plans';
import { PaymentFlow } from './PaymentFlow';
import { ProfileCheck } from './ProfileCheck';
import type { PlanType } from '@/lib/supabase';

type View = 'home' | 'payment' | 'profile';

export function ClientView() {
  const [view, setView] = useState<View>('home');
  const [selectedPlan, setSelectedPlan] = useState<PlanType>('daily');

  function handleSelectPlan(plan: PlanType) {
    setSelectedPlan(plan);
    setView('payment');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function goToProfile() {
    setView('profile');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  return (
    <div>
      <AnimatePresence mode="wait">
        {view === 'home' && (
          <motion.div
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Hero onCTA={() => {
              document.getElementById('planes')?.scrollIntoView({ behavior: 'smooth' });
            }} />
            <Plans onSelect={handleSelectPlan} />

            {/* Profile CTA */}
            <section className="mx-auto max-w-5xl px-6 pb-24">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="glass flex flex-col items-center justify-between gap-4 rounded-2xl p-8 sm:flex-row"
              >
                <div className="flex items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-zinc-800/50">
                    <User className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white">¿Ya eres miembro?</h3>
                    <p className="text-sm text-zinc-400">Consulta el estado de tu membresía</p>
                  </div>
                </div>
                <button
                  onClick={goToProfile}
                  className="flex items-center gap-2 rounded-xl border border-zinc-700/60 bg-zinc-800/40 px-5 py-2.5 text-sm text-zinc-100 transition-colors hover:bg-zinc-700/60"
                >
                  Ver mi estado
                </button>
              </motion.div>
            </section>

            {/* Footer */}
            <footer className="border-t border-zinc-900 px-6 py-12">
              <div className="mx-auto flex max-w-5xl flex-col items-center gap-4 text-center">
                <div className="flex items-center gap-2 text-zinc-400">
                  <Dumbbell className="h-4 w-4 text-accent" />
                  <span className="font-semibold">Gym Local</span>
                </div>
                <p className="text-xs text-zinc-600">
                  Entrena fuerte. Vive mejor.
                </p>
              </div>
            </footer>
          </motion.div>
        )}

        {view === 'payment' && (
          <motion.div
            key="payment"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="min-h-screen"
          >
            <PaymentFlow
              plan={selectedPlan}
              onBack={() => setView('home')}
              onComplete={() => setView('home')}
            />
          </motion.div>
        )}

        {view === 'profile' && (
          <motion.div
            key="profile"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="min-h-screen"
          >
            <div className="mx-auto max-w-lg px-6 pt-24">
              <button
                onClick={() => setView('home')}
                className="text-sm text-zinc-500 transition-colors hover:text-zinc-300"
              >
                ← Volver al inicio
              </button>
            </div>
            <ProfileCheck />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

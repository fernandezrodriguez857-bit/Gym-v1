import { motion } from 'framer-motion';
import { Clock, Calendar, Check } from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { Button } from '@/components/ui/Button';
import { PLAN_PRICES, PLAN_DURATIONS, type PlanType } from '@/lib/supabase';

type PlansProps = {
  onSelect: (plan: PlanType) => void;
};

const plans: {
  type: PlanType;
  name: string;
  price: number;
  duration: string;
  features: string[];
  highlighted?: boolean;
  icon: typeof Clock;
}[] = [
  {
    type: 'daily',
    name: 'Pase Diario',
    price: PLAN_PRICES.daily,
    duration: PLAN_DURATIONS.daily,
    features: ['Acceso completo al gym', 'Hasta 2 horas', 'Sin compromiso'],
    icon: Clock,
  },
  {
    type: 'monthly',
    name: 'Mensualidad',
    price: PLAN_PRICES.monthly,
    duration: PLAN_DURATIONS.monthly,
    features: ['30 días exactos', 'Acceso ilimitado', 'Mejor precio por día', 'Prioridad en horas pico'],
    highlighted: true,
    icon: Calendar,
  },
];

export function Plans({ onSelect }: PlansProps) {
  return (
    <section id="planes" className="mx-auto max-w-5xl px-6 py-24">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-100px' }}
        transition={{ duration: 0.6 }}
        className="mb-12 text-center"
      >
        <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
          Elige tu plan
        </h2>
        <p className="mt-3 text-zinc-400">Sin contratos. Sin complicaciones. Solo entrena.</p>
      </motion.div>

      <div className="grid gap-6 sm:grid-cols-2">
        {plans.map((plan, i) => (
          <motion.div
            key={plan.type}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.6, delay: i * 0.1 }}
          >
            <GlassCard
              hover
              className={`h-full p-8 ${plan.highlighted ? 'border-accent/30 accent-glow' : ''}`}
            >
              <div className="flex items-center justify-between">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-zinc-800/50">
                  <plan.icon className="h-5 w-5 text-accent" />
                </div>
                {plan.highlighted && (
                  <span className="rounded-full border border-accent/30 bg-accent/10 px-3 py-1 text-[10px] font-semibold tracking-wide text-accent">
                    RECOMENDADO
                  </span>
                )}
              </div>

              <h3 className="mt-6 text-xl font-semibold text-white">{plan.name}</h3>
              <p className="mt-1 text-sm text-zinc-500">{plan.duration}</p>

              <div className="mt-6 flex items-baseline gap-1">
                <span className="text-sm text-zinc-400">S/</span>
                <span className="text-4xl font-bold text-white">{plan.price.toFixed(2)}</span>
              </div>

              <ul className="mt-6 space-y-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2.5 text-sm text-zinc-300">
                    <Check className="h-4 w-4 text-accent shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>

              <Button
                fullWidth
                variant={plan.highlighted ? 'primary' : 'secondary'}
                className="mt-8"
                onClick={() => onSelect(plan.type)}
              >
                Pagar con Yape
              </Button>
            </GlassCard>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

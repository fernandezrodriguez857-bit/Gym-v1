import { useState, type FormEvent } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, User, Dumbbell, ArrowLeft } from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { Button } from '@/components/ui/Button';

type AdminLoginProps = {
  onLogin: () => void;
  onBack: () => void;
};

const ADMIN_USER = 'admin';
const ADMIN_PASS = '1234';

export function AdminLogin({ onLogin, onBack }: AdminLoginProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);
  const [shake, setShake] = useState(0);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (username.trim() === ADMIN_USER && password === ADMIN_PASS) {
      onLogin();
    } else {
      setError(true);
      setShake((s) => s + 1);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-6">
      <motion.div
        key={shake}
        animate={
          error
            ? { x: [0, -10, 10, -8, 8, -4, 4, 0] }
            : {}
        }
        transition={{ duration: 0.4 }}
        className="w-full max-w-sm"
      >
        <button
          onClick={onBack}
          className="mb-6 flex items-center gap-2 text-sm text-zinc-500 transition-colors hover:text-zinc-300"
        >
          <ArrowLeft className="h-4 w-4" />
          Volver
        </button>

        <GlassCard className="p-8">
          <div className="mb-8 text-center">
            <motion.div
              initial={{ scale: 0, rotate: -20 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: 'spring', stiffness: 200, damping: 15 }}
              className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-accent/10"
            >
              <Dumbbell className="h-6 w-6 text-accent" />
            </motion.div>
            <h1 className="text-xl font-bold text-white">Panel del Dueño</h1>
            <p className="mt-1 text-sm text-zinc-500">Ingresa tus credenciales para continuar</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="mb-1.5 block text-xs font-medium text-zinc-400">
                Usuario
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-600" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => {
                    setUsername(e.target.value);
                    setError(false);
                  }}
                  placeholder="admin"
                  className={`w-full rounded-xl border bg-zinc-900/50 py-3 pl-10 pr-4 text-sm text-white placeholder-zinc-600 outline-none transition-colors ${
                    error ? 'border-red-500/50' : 'border-zinc-800 focus:border-accent/50'
                  }`}
                />
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-medium text-zinc-400">
                Contraseña
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-600" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError(false);
                  }}
                  placeholder="••••"
                  className={`w-full rounded-xl border bg-zinc-900/50 py-3 pl-10 pr-4 text-sm text-white placeholder-zinc-600 outline-none transition-colors ${
                    error ? 'border-red-500/50' : 'border-zinc-800 focus:border-accent/50'
                  }`}
                />
              </div>
            </div>

            <AnimatePresence>
              {error && (
                <motion.p
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="text-xs text-red-400"
                >
                  Usuario o contraseña incorrectos
                </motion.p>
              )}
            </AnimatePresence>

            <Button type="submit" fullWidth size="lg" className="mt-2">
              Ingresar
            </Button>
          </form>
        </GlassCard>
      </motion.div>
    </div>
  );
}

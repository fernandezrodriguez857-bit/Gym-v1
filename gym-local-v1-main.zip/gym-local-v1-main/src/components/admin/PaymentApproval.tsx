import { motion } from 'framer-motion';
import { Check, X, Receipt, Image as ImageIcon } from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { Button } from '@/components/ui/Button';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { Modal } from '@/components/ui/Modal';
import { Placeholder } from '@/components/ui/Placeholder';
import { type Payment, supabase } from '@/lib/supabase';
import { formatDateTime, computeEndDate } from '@/lib/utils';
import { useState } from 'react';

type PaymentApprovalProps = {
  payments: Payment[];
  onUpdate: () => void;
};

export function PaymentApproval({ payments, onUpdate }: PaymentApprovalProps) {
  const [selected, setSelected] = useState<Payment | null>(null);
  const [processing, setProcessing] = useState(false);

  async function approve(payment: Payment) {
    setProcessing(true);
    try {
      const endDate = computeEndDate(payment.plan_type);

      // Find or create member
      const { data: existing } = await supabase
        .from('members')
        .select('id')
        .eq('dni', payment.dni)
        .maybeSingle();

      let memberId: string;

      if (existing) {
        memberId = existing.id;
        await supabase
          .from('members')
          .update({
            name: payment.name,
            plan_type: payment.plan_type,
            start_date: new Date().toISOString(),
            end_date: endDate,
            status: 'vigente',
          })
          .eq('id', memberId);
      } else {
        const { data: newMember, error } = await supabase
          .from('members')
          .insert({
            name: payment.name,
            dni: payment.dni,
            plan_type: payment.plan_type,
            start_date: new Date().toISOString(),
            end_date: endDate,
            status: 'vigente',
          })
          .select('id')
          .single();

        if (error) throw error;
        memberId = newMember.id;
      }

      // Update payment
      await supabase
        .from('payments')
        .update({
          status: 'aprobado',
          member_id: memberId,
          reviewed_at: new Date().toISOString(),
        })
        .eq('id', payment.id);

      setSelected(null);
      onUpdate();
    } catch (err) {
      console.error('Approve error:', err);
      alert('Error al aprobar el pago. Intenta nuevamente.');
    } finally {
      setProcessing(false);
    }
  }

  async function reject(payment: Payment) {
    setProcessing(true);
    try {
      await supabase
        .from('payments')
        .update({
          status: 'rechazado',
          reviewed_at: new Date().toISOString(),
        })
        .eq('id', payment.id);

      setSelected(null);
      onUpdate();
    } catch (err) {
      console.error('Reject error:', err);
      alert('Error al rechazar el pago.');
    } finally {
      setProcessing(false);
    }
  }

  const pending = payments.filter((p) => p.status === 'pendiente');

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-lg font-semibold text-white">Aprobación de Pagos Yape</h3>
        <span className="rounded-full border border-zinc-800 bg-zinc-900/50 px-3 py-1 text-xs text-zinc-400">
          {pending.length} pendiente{pending.length !== 1 ? 's' : ''}
        </span>
      </div>

      {pending.length === 0 ? (
        <GlassCard className="p-8 text-center">
          <Check className="mx-auto mb-3 h-8 w-8 text-green-400" />
          <p className="text-sm text-zinc-400">No hay pagos pendientes de revisión</p>
        </GlassCard>
      ) : (
        <div className="space-y-3">
          {pending.map((payment, i) => (
            <motion.div
              key={payment.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.05 }}
            >
              <GlassCard
                hover
                className="flex cursor-pointer items-center justify-between p-4"
                onClick={() => setSelected(payment)}
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-zinc-800/50">
                    <Receipt className="h-4 w-4 text-zinc-400" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">{payment.name}</p>
                    <p className="text-xs text-zinc-500">
                      DNI: {payment.dni} · S/ {payment.amount.toFixed(2)}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="hidden text-xs text-zinc-500 sm:block">
                    {formatDateTime(payment.created_at)}
                  </span>
                  <StatusBadge status="pendiente" size="sm" />
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      )}

      {/* Detail Modal */}
      <Modal
        open={!!selected}
        onClose={() => setSelected(null)}
        title="Revisar comprobante"
      >
        {selected && (
          <div>
            <div className="mb-4 grid grid-cols-2 gap-3">
              <div className="rounded-xl border border-zinc-800 bg-zinc-900/40 p-3">
                <p className="text-[10px] font-medium tracking-wide text-zinc-500">CLIENTE</p>
                <p className="mt-1 text-sm font-semibold text-white">{selected.name}</p>
              </div>
              <div className="rounded-xl border border-zinc-800 bg-zinc-900/40 p-3">
                <p className="text-[10px] font-medium tracking-wide text-zinc-500">DNI</p>
                <p className="mt-1 text-sm font-semibold text-white">{selected.dni}</p>
              </div>
              <div className="rounded-xl border border-zinc-800 bg-zinc-900/40 p-3">
                <p className="text-[10px] font-medium tracking-wide text-zinc-500">PLAN</p>
                <p className="mt-1 text-sm font-semibold text-white">
                  {selected.plan_type === 'daily' ? 'Pase Diario' : 'Mensualidad'}
                </p>
              </div>
              <div className="rounded-xl border border-zinc-800 bg-zinc-900/40 p-3">
                <p className="text-[10px] font-medium tracking-wide text-zinc-500">MONTO</p>
                <p className="mt-1 text-sm font-semibold text-accent">
                  S/ {selected.amount.toFixed(2)}
                </p>
              </div>
            </div>

            <p className="mb-2 text-xs text-zinc-500">Captura del comprobante:</p>
            {selected.receipt_data ? (
              <div className="overflow-hidden rounded-xl border border-zinc-800 bg-zinc-900/40">
                <img
                  src={selected.receipt_data}
                  alt="Comprobante Yape"
                  className="mx-auto max-h-[400px] w-full object-contain"
                />
              </div>
            ) : (
              <Placeholder
                label="Sin captura adjunta"
                aspect="video"
                icon={<ImageIcon className="h-5 w-5" />}
              />
            )}

            <div className="mt-6 flex gap-3">
              <Button
                variant="danger"
                fullWidth
                onClick={() => reject(selected)}
                disabled={processing}
              >
                <span className="flex items-center justify-center gap-2">
                  <X className="h-4 w-4" />
                  Rechazar
                </span>
              </Button>
              <Button
                fullWidth
                onClick={() => approve(selected)}
                disabled={processing}
              >
                <span className="flex items-center justify-center gap-2">
                  <Check className="h-4 w-4" />
                  {processing ? 'Procesando...' : 'Aprobar'}
                </span>
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

import { motion } from 'framer-motion';
import { AlertTriangle, Users, Clock, TrendingUp, Timer } from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { CountdownTimer } from '@/components/ui/CountdownTimer';
import { type Member, type Payment } from '@/lib/supabase';
import { getDaysRemaining, getMemberStatus } from '@/lib/utils';

export type StatFilter = 'all' | 'vigente' | 'proximo' | 'vencido' | 'pendiente';

type StatsProps = {
  members: Member[];
  pendingPayments: Payment[];
  activeFilter: StatFilter;
  onFilterChange: (filter: StatFilter) => void;
};

export function Stats({ members, pendingPayments, activeFilter, onFilterChange }: StatsProps) {
  const vigente = members.filter((m) => getMemberStatus(m) === 'vigente').length;
  const proximo = members.filter((m) => getMemberStatus(m) === 'proximo').length;
  const vencido = members.filter((m) => getMemberStatus(m) === 'vencido').length;

  const cards: {
    label: string;
    value: number;
    icon: typeof Users;
    color: string;
    bg: string;
    filter: StatFilter;
  }[] = [
    {
      label: 'Miembros vigentes',
      value: vigente,
      icon: Users,
      color: 'text-green-400',
      bg: 'bg-green-500/10',
      filter: 'vigente',
    },
    {
      label: 'Por vencer',
      value: proximo,
      icon: Clock,
      color: 'text-yellow-400',
      bg: 'bg-yellow-500/10',
      filter: 'proximo',
    },
    {
      label: 'Vencidos',
      value: vencido,
      icon: AlertTriangle,
      color: 'text-red-400',
      bg: 'bg-red-500/10',
      filter: 'vencido',
    },
    {
      label: 'Pagos pendientes',
      value: pendingPayments.length,
      icon: TrendingUp,
      color: 'text-accent',
      bg: 'bg-accent/10',
      filter: 'pendiente',
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
      {cards.map((card, i) => {
        const isActive = activeFilter === card.filter;
        return (
          <motion.button
            key={card.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: i * 0.08 }}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => onFilterChange(isActive ? 'all' : card.filter)}
            className="text-left"
          >
            <GlassCard
              className={`p-5 transition-all duration-200 ${
                isActive
                  ? 'ring-2 ring-accent/40 border-accent/30'
                  : ''
              }`}
            >
              <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${card.bg}`}>
                <card.icon className={`h-5 w-5 ${card.color}`} />
              </div>
              <p className="mt-4 text-3xl font-bold text-white">{card.value}</p>
              <div className="mt-1 flex items-center gap-1.5">
                <p className="text-xs text-zinc-500">{card.label}</p>
                {isActive && (
                  <motion.span
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-[10px] font-medium text-accent"
                  >
                    · Filtrando
                  </motion.span>
                )}
              </div>
            </GlassCard>
          </motion.button>
        );
      })}
    </div>
  );
}

export function ActiveDailyTimers({ members }: { members: Member[] }) {
  const dailyActive = members.filter(
    (m) => m.plan_type === 'daily' && getMemberStatus(m) === 'vigente'
  );

  if (dailyActive.length === 0) return null;

  return (
    <GlassCard className="overflow-hidden">
      <div className="flex items-center gap-3 border-b border-zinc-800 p-5">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/10">
          <Timer className="h-5 w-5 text-accent" />
        </div>
        <div>
          <h3 className="font-semibold text-white">Pases diarios activos</h3>
          <p className="text-sm text-zinc-400">
            {dailyActive.length} cliente{dailyActive.length !== 1 ? 's' : ''} con tiempo en curso
          </p>
        </div>
      </div>

      <div className="divide-y divide-zinc-800/60">
        {dailyActive.map((member, i) => (
          <motion.div
            key={member.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: i * 0.05 }}
            className="flex items-center justify-between p-4"
          >
            <div className="flex items-center gap-3">
              <div className="h-2 w-2 rounded-full bg-accent" />
              <div>
                <p className="text-sm font-medium text-white">{member.name}</p>
                <p className="text-xs text-zinc-500">DNI: {member.dni}</p>
              </div>
            </div>
            <CountdownTimer endDate={member.end_date} compact />
          </motion.div>
        ))}
      </div>
    </GlassCard>
  );
}

export function ExpiringAlerts({ members }: { members: Member[] }) {
  const expiring = members
    .map((m) => ({ member: m, status: getMemberStatus(m), days: getDaysRemaining(m.end_date) }))
    .filter((x) => x.status === 'proximo' || x.status === 'vencido')
    .sort((a, b) => a.days - b.days);

  if (expiring.length === 0) {
    return (
      <GlassCard className="p-6">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-green-500/10">
            <Users className="h-5 w-5 text-green-400" />
          </div>
          <div>
            <h3 className="font-semibold text-white">Sin alertas</h3>
            <p className="text-sm text-zinc-400">Todos los miembros están al día</p>
          </div>
        </div>
      </GlassCard>
    );
  }

  return (
    <GlassCard className="overflow-hidden">
      <div className="flex items-center gap-3 border-b border-zinc-800 p-5">
        <motion.div
          animate={{ opacity: [1, 0.5, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="flex h-10 w-10 items-center justify-center rounded-xl bg-red-500/10"
        >
          <AlertTriangle className="h-5 w-5 text-red-400" />
        </motion.div>
        <div>
          <h3 className="font-semibold text-white">Alertas inmediatas</h3>
          <p className="text-sm text-zinc-400">
            {expiring.length} miembro{expiring.length !== 1 ? 's' : ''} requiere{expiring.length !== 1 ? 'n' : ''} atención
          </p>
        </div>
      </div>

      <div className="divide-y divide-zinc-800/60">
        {expiring.map(({ member, status, days }, i) => (
          <motion.div
            key={member.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: i * 0.05 }}
            className="flex items-center justify-between p-4 transition-colors hover:bg-zinc-800/20"
          >
            <div className="flex items-center gap-3">
              <div
                className={`h-2 w-2 rounded-full ${
                  status === 'vencido' ? 'bg-red-400' : 'bg-yellow-400'
                }`}
              />
              <div>
                <p className="text-sm font-medium text-white">{member.name}</p>
                <p className="text-xs text-zinc-500">DNI: {member.dni}</p>
              </div>
            </div>
            <div className="text-right">
              <p
                className={`text-sm font-semibold ${
                  status === 'vencido' ? 'text-red-400' : 'text-yellow-400'
                }`}
              >
                {days < 0 ? `Venció hace ${Math.abs(days)}d` : `${days}d restantes`}
              </p>
              <p className="text-xs text-zinc-500">
                {member.plan_type === 'daily' ? 'Pase diario' : 'Mensualidad'}
              </p>
            </div>
          </motion.div>
        ))}
      </div>
    </GlassCard>
  );
}

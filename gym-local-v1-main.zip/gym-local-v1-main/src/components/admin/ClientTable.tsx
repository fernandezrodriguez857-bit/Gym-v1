import { motion } from 'framer-motion';
import { useState, useEffect } from 'react';
import { Search, ArrowUpDown, Dumbbell, X } from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { CountdownTimer } from '@/components/ui/CountdownTimer';
import { type Member } from '@/lib/supabase';
import { getMemberStatus, formatDate, getDaysRemaining } from '@/lib/utils';
import type { StatFilter } from './Stats';

type ClientTableProps = {
  members: Member[];
  filter: StatFilter;
};

type SortKey = 'name' | 'dni' | 'plan_type' | 'end_date' | 'status';

const FILTER_LABELS: Record<Exclude<StatFilter, 'all'>, string> = {
  vigente: 'Vigentes',
  proximo: 'Por vencer',
  vencido: 'Vencidos',
  pendiente: 'Relacionados a pagos pendientes',
};

export function ClientTable({ members, filter }: ClientTableProps) {
  const [search, setSearch] = useState('');
  const [sortKey, setSortKey] = useState<SortKey>('end_date');
  const [sortAsc, setSortAsc] = useState(true);

  useEffect(() => {
    if (filter !== 'all') setSearch('');
  }, [filter]);

  const statusFiltered = members.filter((m) => {
    if (filter === 'all' || filter === 'pendiente') return true;
    return getMemberStatus(m) === filter;
  });

  const filtered = statusFiltered
    .filter(
      (m) =>
        m.name.toLowerCase().includes(search.toLowerCase()) ||
        m.dni.includes(search)
    )
    .sort((a, b) => {
      let av: string | number = a[sortKey];
      let bv: string | number = b[sortKey];
      if (sortKey === 'status') {
        av = getMemberStatus(a);
        bv = getMemberStatus(b);
      }
      if (av < bv) return sortAsc ? -1 : 1;
      if (av > bv) return sortAsc ? 1 : -1;
      return 0;
    });

  function toggleSort(key: SortKey) {
    if (sortKey === key) {
      setSortAsc(!sortAsc);
    } else {
      setSortKey(key);
      setSortAsc(true);
    }
  }

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h3 className="text-lg font-semibold text-white">Base de Clientes</h3>
          {filter !== 'all' && (
            <span className="flex items-center gap-1.5 rounded-full border border-accent/30 bg-accent/10 px-3 py-1 text-xs font-medium text-accent">
              {FILTER_LABELS[filter]}
              <span className="h-1 w-1 rounded-full bg-accent/50" />
            </span>
          )}
        </div>
        <span className="rounded-full border border-zinc-800 bg-zinc-900/50 px-3 py-1 text-xs text-zinc-400">
          {filtered.length} registrado{filtered.length !== 1 ? 's' : ''}
        </span>
      </div>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-600" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Buscar por nombre o DNI..."
          className="w-full rounded-xl border border-zinc-800 bg-zinc-900/50 py-2.5 pl-10 pr-4 text-sm text-white placeholder-zinc-600 outline-none transition-colors focus:border-accent/50"
        />
        {search && (
          <button
            onClick={() => setSearch('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-zinc-400"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      <GlassCard className="overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-12 text-center">
            <Dumbbell className="mx-auto mb-3 h-8 w-8 text-zinc-700" />
            <p className="text-sm text-zinc-500">
              {members.length === 0 ? 'No hay clientes registrados aún' : 'Sin resultados para este filtro'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-zinc-800 text-xs text-zinc-500">
                  <th className="px-4 py-3 text-left font-medium">
                    <button onClick={() => toggleSort('name')} className="flex items-center gap-1 hover:text-zinc-300">
                      Nombre <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </th>
                  <th className="px-4 py-3 text-left font-medium">
                    <button onClick={() => toggleSort('dni')} className="flex items-center gap-1 hover:text-zinc-300">
                      DNI <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </th>
                  <th className="hidden px-4 py-3 text-left font-medium sm:table-cell">
                    <button onClick={() => toggleSort('plan_type')} className="flex items-center gap-1 hover:text-zinc-300">
                      Plan <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </th>
                  <th className="hidden px-4 py-3 text-left font-medium md:table-cell">
                    <button onClick={() => toggleSort('end_date')} className="flex items-center gap-1 hover:text-zinc-300">
                      Corte <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </th>
                  <th className="px-4 py-3 text-right font-medium">
                    <button onClick={() => toggleSort('status')} className="flex items-center gap-1 hover:text-zinc-300">
                      Estado <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60">
                {filtered.map((member, i) => {
                  const status = getMemberStatus(member);
                  const days = getDaysRemaining(member.end_date);
                  const isDailyActive = member.plan_type === 'daily' && status === 'vigente';
                  return (
                    <motion.tr
                      key={member.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.2, delay: i * 0.03 }}
                      className="transition-colors hover:bg-zinc-800/20"
                    >
                      <td className="px-4 py-3">
                        <p className="font-medium text-white">{member.name}</p>
                        <p className="text-xs text-zinc-600 sm:hidden">{member.dni}</p>
                        {isDailyActive && (
                          <div className="mt-1 sm:hidden">
                            <CountdownTimer endDate={member.end_date} compact />
                          </div>
                        )}
                      </td>
                      <td className="hidden px-4 py-3 text-zinc-400 sm:table-cell">{member.dni}</td>
                      <td className="hidden px-4 py-3 text-zinc-400 sm:table-cell">
                        {member.plan_type === 'daily' ? 'Diario' : 'Mensual'}
                        {isDailyActive && (
                          <div className="mt-1">
                            <CountdownTimer endDate={member.end_date} compact />
                          </div>
                        )}
                      </td>
                      <td className="hidden px-4 py-3 text-zinc-400 md:table-cell">
                        {isDailyActive ? (
                          <CountdownTimer endDate={member.end_date} compact />
                        ) : (
                          <div>
                            {formatDate(member.end_date)}
                            <span className="ml-2 text-xs text-zinc-600">
                              ({days < 0 ? `${Math.abs(days)}d atrás` : `${days}d`})
                            </span>
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <StatusBadge status={status} size="sm" />
                      </td>
                    </motion.tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </GlassCard>
    </div>
  );
}

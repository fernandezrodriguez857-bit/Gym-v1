import { useEffect, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Dumbbell, RefreshCw } from 'lucide-react';
import { Stats, ExpiringAlerts, ActiveDailyTimers, type StatFilter } from './Stats';
import { PaymentApproval } from './PaymentApproval';
import { ClientTable } from './ClientTable';
import { Button } from '@/components/ui/Button';
import { supabase, type Member, type Payment } from '@/lib/supabase';

export function AdminView() {
  const [members, setMembers] = useState<Member[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState<StatFilter>('all');

  const loadData = useCallback(async () => {
    setRefreshing(true);
    try {
      const [membersRes, paymentsRes] = await Promise.all([
        supabase.from('members').select('*').order('created_at', { ascending: false }),
        supabase.from('payments').select('*').order('created_at', { ascending: false }),
      ]);

      if (membersRes.error) throw membersRes.error;
      if (paymentsRes.error) throw paymentsRes.error;

      setMembers(membersRes.data as Member[]);
      setPayments(paymentsRes.data as Payment[]);
    } catch (err) {
      console.error('Load error:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
        >
          <RefreshCw className="h-6 w-6 text-zinc-600" />
        </motion.div>
      </div>
    );
  }

  const pendingPayments = payments.filter((p) => p.status === 'pendiente');

  return (
    <div className="mx-auto max-w-6xl px-4 pb-24 pt-24 sm:px-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8 flex items-center justify-between"
      >
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/10">
            <Dumbbell className="h-5 w-5 text-accent" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">Panel del Dueño</h1>
            <p className="text-xs text-zinc-500">Gym Local · Administración</p>
          </div>
        </div>
        <Button
          variant="secondary"
          size="sm"
          onClick={loadData}
          disabled={refreshing}
        >
          <span className="flex items-center gap-2">
            <RefreshCw className={`h-3.5 w-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Actualizar</span>
          </span>
        </Button>
      </motion.div>

      {/* Stats */}
      <div className="mb-8">
        <Stats
          members={members}
          pendingPayments={pendingPayments}
          activeFilter={filter}
          onFilterChange={setFilter}
        />
      </div>

      {/* Alerts + Payments */}
      <div className="mb-8 grid gap-6 lg:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <ExpiringAlerts members={members} />
        </motion.div>
        <div className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.12 }}
          >
            <ActiveDailyTimers members={members} />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.15 }}
          >
            <PaymentApproval payments={payments} onUpdate={loadData} />
          </motion.div>
        </div>
      </div>

      {/* Client Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <ClientTable members={members} filter={filter} />
      </motion.div>
    </div>
  );
}

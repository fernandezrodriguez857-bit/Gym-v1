import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Timer, AlertCircle } from 'lucide-react';

type CountdownTimerProps = {
  endDate: string;
  compact?: boolean;
};

function getRemaining(endDate: string): { hours: number; minutes: number; seconds: number; expired: boolean } {
  const end = new Date(endDate).getTime();
  const now = Date.now();
  const diff = end - now;

  if (diff <= 0) {
    return { hours: 0, minutes: 0, seconds: 0, expired: true };
  }

  const hours = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diff % (1000 * 60)) / 1000);

  return { hours, minutes, seconds, expired: false };
}

export function CountdownTimer({ endDate, compact = false }: CountdownTimerProps) {
  const [time, setTime] = useState(() => getRemaining(endDate));

  useEffect(() => {
    const interval = setInterval(() => {
      setTime(getRemaining(endDate));
    }, 1000);
    return () => clearInterval(interval);
  }, [endDate]);

  const isLow = !time.expired && time.hours === 0 && time.minutes < 30;
  const isCritical = !time.expired && time.hours === 0 && time.minutes < 10;

  if (time.expired) {
    return (
      <div className={`flex items-center gap-2 ${compact ? 'text-xs' : 'text-sm'} text-red-400`}>
        <AlertCircle className={compact ? 'h-3 w-3' : 'h-4 w-4'} />
        <span>Tiempo agotado</span>
      </div>
    );
  }

  const pad = (n: number) => n.toString().padStart(2, '0');

  if (compact) {
    return (
      <div
        className={`flex items-center gap-1.5 text-xs font-semibold ${
          isCritical ? 'text-red-400' : isLow ? 'text-yellow-400' : 'text-accent'
        }`}
      >
        {isCritical && (
          <motion.span
            animate={{ opacity: [1, 0.3, 1] }}
            transition={{ duration: 0.8, repeat: Infinity }}
          >
            <AlertCircle className="h-3 w-3" />
          </motion.span>
        )}
        <Timer className="h-3 w-3" />
        <span>
          {pad(time.hours)}:{pad(time.minutes)}:{pad(time.seconds)}
        </span>
      </div>
    );
  }

  return (
    <motion.div
      animate={isCritical ? { scale: [1, 1.02, 1] } : {}}
      transition={{ duration: 0.8, repeat: isCritical ? Infinity : 0 }}
      className={`rounded-2xl border p-6 ${
        isCritical
          ? 'border-red-500/30 bg-red-500/10'
          : isLow
          ? 'border-yellow-500/30 bg-yellow-500/10'
          : 'border-zinc-800 bg-zinc-900/40'
      }`}
    >
      <div className="mb-4 flex items-center gap-2">
        <Timer
          className={`h-5 w-5 ${
            isCritical ? 'text-red-400' : isLow ? 'text-yellow-400' : 'text-accent'
          }`}
        />
        <span className="text-sm font-medium text-zinc-300">Tiempo restante</span>
        {isCritical && (
          <motion.span
            animate={{ opacity: [1, 0.3, 1] }}
            transition={{ duration: 0.8, repeat: Infinity }}
            className="ml-auto flex items-center gap-1 text-xs text-red-400"
          >
            <AlertCircle className="h-3 w-3" />
            ¡Urgente!
          </motion.span>
        )}
        {isLow && !isCritical && (
          <span className="ml-auto text-xs text-yellow-400">Por agotarse</span>
        )}
      </div>

      <div className="flex items-center justify-center gap-2 sm:gap-4">
        {[
          { label: 'Horas', value: time.hours },
          { label: 'Min', value: time.minutes },
          { label: 'Seg', value: time.seconds },
        ].map((unit) => (
          <div key={unit.label} className="flex flex-col items-center">
            <div
              className={`flex h-16 w-16 items-center justify-center rounded-2xl border text-2xl font-bold tabular-nums sm:h-20 sm:w-20 sm:text-3xl ${
                isCritical
                  ? 'border-red-500/20 bg-red-500/5 text-red-400'
                  : isLow
                  ? 'border-yellow-500/20 bg-yellow-500/5 text-yellow-400'
                  : 'border-zinc-800 bg-zinc-900/50 text-accent'
              }`}
            >
              {pad(unit.value)}
            </div>
            <span className="mt-2 text-[10px] font-medium tracking-wide text-zinc-500">
              {unit.label}
            </span>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

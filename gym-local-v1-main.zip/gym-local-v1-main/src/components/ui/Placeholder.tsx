import { type ReactNode } from 'react';
import { motion } from 'framer-motion';
import { Image } from 'lucide-react';

type PlaceholderProps = {
  label: string;
  className?: string;
  icon?: ReactNode;
  aspect?: 'square' | 'video' | 'wide' | 'auto';
};

export function Placeholder({
  label,
  className = '',
  icon,
  aspect = 'auto',
}: PlaceholderProps) {
  const aspectClass =
    aspect === 'square'
      ? 'aspect-square'
      : aspect === 'video'
      ? 'aspect-video'
      : aspect === 'wide'
      ? 'aspect-[21/9]'
      : '';

  return (
    <div
      className={`relative flex flex-col items-center justify-center rounded-2xl border border-dashed border-zinc-700/60 bg-zinc-900/30 ${aspectClass} ${className}`}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
        className="flex flex-col items-center gap-3 text-center"
      >
        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-zinc-800/50 text-zinc-500">
          {icon ?? <Image className="h-5 w-5" />}
        </div>
        <p className="text-xs font-medium tracking-wide text-zinc-500">{label}</p>
      </motion.div>
    </div>
  );
}

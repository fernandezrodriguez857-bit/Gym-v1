import { motion } from 'framer-motion';

type StatusBadgeProps = {
  status: 'vigente' | 'proximo' | 'vencido' | 'pendiente' | 'aprobado' | 'rechazado';
  size?: 'sm' | 'md';
};

const config: Record<
  StatusBadgeProps['status'],
  { label: string; classes: string; dot: string }
> = {
  vigente: {
    label: 'Vigente',
    classes: 'bg-green-500/10 text-green-400 border-green-500/20',
    dot: 'bg-green-400',
  },
  proximo: {
    label: 'Próximo a vencer',
    classes: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
    dot: 'bg-yellow-400',
  },
  vencido: {
    label: 'Vencido',
    classes: 'bg-red-500/10 text-red-400 border-red-500/20',
    dot: 'bg-red-400',
  },
  pendiente: {
    label: 'Pendiente',
    classes: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
    dot: 'bg-yellow-400',
  },
  aprobado: {
    label: 'Aprobado',
    classes: 'bg-green-500/10 text-green-400 border-green-500/20',
    dot: 'bg-green-400',
  },
  rechazado: {
    label: 'Rechazado',
    classes: 'bg-red-500/10 text-red-400 border-red-500/20',
    dot: 'bg-red-400',
  },
};

export function StatusBadge({ status, size = 'md' }: StatusBadgeProps) {
  const c = config[status];
  const sizeClass = size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-3 py-1 text-xs';
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border font-medium ${c.classes} ${sizeClass}`}
    >
      <motion.span
        animate={{ opacity: [1, 0.5, 1] }}
        transition={{ duration: 2, repeat: Infinity }}
        className={`h-1.5 w-1.5 rounded-full ${c.dot}`}
      />
      {c.label}
    </span>
  );
}

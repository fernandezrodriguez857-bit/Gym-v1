import { type ButtonHTMLAttributes, type ReactNode } from 'react';
import { motion } from 'framer-motion';

type ButtonProps = {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  fullWidth?: boolean;
} & ButtonHTMLAttributes<HTMLButtonElement>;

export function Button({
  children,
  variant = 'primary',
  size = 'md',
  className = '',
  fullWidth = false,
  ...props
}: ButtonProps) {
  const variants = {
    primary:
      'bg-accent text-zinc-950 font-semibold hover:bg-accent-dark active:bg-accent-dark',
    secondary:
      'bg-zinc-800/60 text-zinc-100 border border-zinc-700/60 hover:bg-zinc-700/60',
    ghost: 'text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800/40',
    danger:
      'bg-red-500/90 text-white font-semibold hover:bg-red-500 active:bg-red-600',
  };

  const sizes = {
    sm: 'px-3 py-1.5 text-xs rounded-lg',
    md: 'px-5 py-2.5 text-sm rounded-xl',
    lg: 'px-8 py-4 text-base rounded-2xl',
  };

  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={`${variants[variant]} ${sizes[size]} ${fullWidth ? 'w-full' : ''} transition-colors duration-200 disabled:opacity-40 disabled:cursor-not-allowed ${className}`}
      {...(props as any)}
    >
      {children}
    </motion.button>
  );
}

import { type ReactNode } from 'react';
import { motion, type HTMLMotionProps } from 'framer-motion';

type GlassCardProps = {
  children: ReactNode;
  className?: string;
  hover?: boolean;
} & Omit<HTMLMotionProps<'div'>, 'children'>;

export function GlassCard({
  children,
  className = '',
  hover = false,
  ...props
}: GlassCardProps) {
  return (
    <motion.div
      className={`glass rounded-2xl ${hover ? 'transition-colors hover:border-zinc-700/80' : ''} ${className}`}
      {...props}
    >
      {children}
    </motion.div>
  );
}

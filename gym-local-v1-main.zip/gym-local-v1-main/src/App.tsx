import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { RoleSwitcher, type Role } from '@/components/RoleSwitcher';
import { ClientView } from '@/components/client/ClientView';
import { AdminView } from '@/components/admin/AdminView';
import { AdminLogin } from '@/components/admin/AdminLogin';

function App() {
  const [role, setRole] = useState<Role>('client');
  const [adminAuthed, setAdminAuthed] = useState(false);

  function handleRoleChange(newRole: Role) {
    if (newRole === 'admin' && !adminAuthed) {
      setRole('admin');
    } else {
      setRole(newRole);
    }
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <RoleSwitcher role={role} onChange={handleRoleChange} />

      <AnimatePresence mode="wait">
        {role === 'client' ? (
          <motion.div
            key="client"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <ClientView />
          </motion.div>
        ) : adminAuthed ? (
          <motion.div
            key="admin"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <AdminView />
          </motion.div>
        ) : (
          <motion.div
            key="admin-login"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <AdminLogin
              onLogin={() => setAdminAuthed(true)}
              onBack={() => setRole('client')}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;

import type { Member } from './supabase';

export function getDaysRemaining(endDate: string): number {
  const end = new Date(endDate).getTime();
  const now = Date.now();
  const diff = end - now;
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

export function getMemberStatus(member: Member): 'vigente' | 'proximo' | 'vencido' {
  const days = getDaysRemaining(member.end_date);
  if (days < 0) return 'vencido';
  if (days <= 3) return 'proximo';
  return 'vigente';
}

export function formatDate(date: string): string {
  return new Date(date).toLocaleDateString('es-PE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });
}

export function formatDateTime(date: string): string {
  return new Date(date).toLocaleString('es-PE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function computeEndDate(planType: 'daily' | 'monthly'): string {
  const now = new Date();
  if (planType === 'daily') {
    now.setHours(now.getHours() + 2);
  } else {
    now.setDate(now.getDate() + 30);
  }
  return now.toISOString();
}

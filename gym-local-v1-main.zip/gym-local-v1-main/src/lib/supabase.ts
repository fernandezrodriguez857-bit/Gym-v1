import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Member = {
  id: string;
  name: string;
  dni: string;
  phone: string | null;
  plan_type: 'daily' | 'monthly';
  start_date: string;
  end_date: string;
  status: 'vigente' | 'pendiente' | 'vencido';
  created_at: string;
  loyalty_start_date: string | null;
};

export type Payment = {
  id: string;
  name: string;
  dni: string;
  plan_type: 'daily' | 'monthly';
  amount: number;
  status: 'pendiente' | 'aprobado' | 'rechazado';
  receipt_data: string | null;
  member_id: string | null;
  created_at: string;
  reviewed_at: string | null;
};

export type PlanType = 'daily' | 'monthly';

export const PLAN_PRICES: Record<PlanType, number> = {
  daily: 4.0,
  monthly: 60.0,
};

export const PLAN_DURATIONS: Record<PlanType, string> = {
  daily: '2 horas máximo',
  monthly: '30 días exactos',
};

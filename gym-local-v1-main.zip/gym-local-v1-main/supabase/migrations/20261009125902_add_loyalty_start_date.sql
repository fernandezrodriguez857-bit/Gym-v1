/*
# Add loyalty_start_date column to members

1. Modified Tables
- `members`: Added `loyalty_start_date` (timestamptz, nullable) — allows clients to set
  the date they started training at the gym, for the loyalty/antigüedad feature.
  Defaults to NULL; the app falls back to `created_at` when NULL.

2. Security
- No changes to RLS — existing anon/authenticated policies already cover the new column.

3. Important Notes
- This column is user-editable from the client profile screen.
- When NULL, the app uses `created_at` as the loyalty start date.
- Uses IF NOT EXISTS to be idempotent.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'members' AND column_name = 'loyalty_start_date'
  ) THEN
    ALTER TABLE members ADD COLUMN loyalty_start_date timestamptz;
  END IF;
END $$;

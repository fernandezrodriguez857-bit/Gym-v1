/*
# Create Gym Local management tables

1. New Tables
- `members`: Stores gym member records with membership status and dates.
  - id (uuid, primary key)
  - name (text, not null) — member's full name
  - dni (text, not null, unique) — Peruvian national ID
  - phone (text, nullable) — optional contact number
  - plan_type (text, not null) — 'daily' or 'monthly'
  - start_date (timestamptz, not null) — when the membership/pase begins
  - end_date (timestamptz, not null) — when the membership/pase expires
  - status (text, not null, default 'vigente') — 'vigente', 'pendiente', 'vencido'
  - created_at (timestamptz, default now())

- `payments`: Stores Yape payment submissions for admin approval.
  - id (uuid, primary key)
  - name (text, not null) — payer's name (from the payment form)
  - dni (text, not null) — payer's DNI (from the payment form)
  - plan_type (text, not null) — 'daily' or 'monthly'
  - amount (numeric, not null) — amount paid in soles
  - status (text, not null, default 'pendiente') — 'pendiente', 'aprobado', 'rechazado'
  - receipt_data (text, nullable) — base64 or description of uploaded receipt screenshot
  - member_id (uuid, nullable, references members) — linked member after approval
  - created_at (timestamptz, default now())
  - reviewed_at (timestamptz, nullable) — when admin approved/rejected

2. Security
- Enable RLS on both tables.
- Allow anon + authenticated full CRUD (single-tenant, no auth — the app uses a role toggle in the UI, not sign-in).
- All data is intentionally shared between clients and the admin view.

3. Important Notes
- This is a no-auth app: clients submit payments and check status by DNI without logging in.
- The admin panel is accessed via a UI role toggle, not authentication.
- When a payment is approved, the app creates or updates a member record accordingly.
*/

CREATE TABLE IF NOT EXISTS members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  dni text NOT NULL UNIQUE,
  phone text,
  plan_type text NOT NULL CHECK (plan_type IN ('daily', 'monthly')),
  start_date timestamptz NOT NULL DEFAULT now(),
  end_date timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'vigente' CHECK (status IN ('vigente', 'pendiente', 'vencido')),
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  dni text NOT NULL,
  plan_type text NOT NULL CHECK (plan_type IN ('daily', 'monthly')),
  amount numeric NOT NULL,
  status text NOT NULL DEFAULT 'pendiente' CHECK (status IN ('pendiente', 'aprobado', 'rechazado')),
  receipt_data text,
  member_id uuid REFERENCES members(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  reviewed_at timestamptz
);

ALTER TABLE members ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- members policies (anon + authenticated, single-tenant)
DROP POLICY IF EXISTS "anon_select_members" ON members;
CREATE POLICY "anon_select_members" ON members FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_members" ON members;
CREATE POLICY "anon_insert_members" ON members FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_members" ON members;
CREATE POLICY "anon_update_members" ON members FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_members" ON members;
CREATE POLICY "anon_delete_members" ON members FOR DELETE
  TO anon, authenticated USING (true);

-- payments policies (anon + authenticated, single-tenant)
DROP POLICY IF EXISTS "anon_select_payments" ON payments;
CREATE POLICY "anon_select_payments" ON payments FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_payments" ON payments;
CREATE POLICY "anon_insert_payments" ON payments FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_payments" ON payments;
CREATE POLICY "anon_update_payments" ON payments FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_payments" ON payments;
CREATE POLICY "anon_delete_payments" ON payments FOR DELETE
  TO anon, authenticated USING (true);

-- Indexes for frequent lookups
CREATE INDEX IF NOT EXISTS idx_members_dni ON members(dni);
CREATE INDEX IF NOT EXISTS idx_members_status ON members(status);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_payments_dni ON payments(dni);
